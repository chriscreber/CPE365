-- Christopher Creber
-- ccreber@calpoly.edu

INSERT INTO airlines VALUES (1,'United Airlines','UAL','USA');
INSERT INTO airlines VALUES (2,'US Airways','USAir','USA');
INSERT INTO airlines VALUES (3,'Delta Airlines','Delta','USA');
INSERT INTO airlines VALUES (4,'Southwest Airlines','Southwest','USA');
INSERT INTO airlines VALUES (5,'American Airlines','American','USA');
INSERT INTO airlines VALUES (6,'Northwest Airlines','Northwest','USA');
INSERT INTO airlines VALUES (7,'Continental Airlines','Continental','USA');
INSERT INTO airlines VALUES (8,'JetBlue Airways','JetBlue','USA');
INSERT INTO airlines VALUES (9,'Frontier Airlines','Frontier','USA');
INSERT INTO airlines VALUES (10,'AirTran Airways','AirTran','USA');
INSERT INTO airlines VALUES (11,'Allegiant Air','Allegiant','USA');
INSERT INTO airlines VALUES (12,'Virgin America','Virgin','USA');
