-- Christopher Creber
-- ccreber@calpoly.edu

SELECT * FROM airlines;

SELECT COUNT(*) FROM airlines;

SELECT * FROM airports100;

SELECT COUNT(*) FROM airports100;

SELECT * FROM flights;

SELECT COUNT(*) FROM flights;
