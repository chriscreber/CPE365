-- Christopher Creber
-- ccreber@calpoly.edu

-- AIRLINES CLEANUP

DROP TABLE flights;
DROP TABLE airlines;
DROP TABLE airports;
