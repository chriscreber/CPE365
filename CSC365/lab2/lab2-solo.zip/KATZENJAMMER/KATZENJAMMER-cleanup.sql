-- Christopher Creber
-- ccreber@calpoly.edu

-- KATZENJAMMER CLEANUP

DROP TABLE vocals;
DROP TABLE tracklists;
DROP TABLE performance;
DROP TABLE instruments;
DROP TABLE albums;
DROP TABLE songs;
DROP TABLE band;
