-- Christopher Creber
-- ccreber@calpoly.edu

SELECT * FROM albums;

SELECT COUNT(*) FROM albums;

SELECT * FROM band;

SELECT COUNT(*) FROM band;

SELECT * FROM instruments;

SELECT COUNT(*) FROM instruments;

SELECT * FROM performance;

SELECT COUNT(*) FROM performance;

SELECT * FROM songs;

SELECT COUNT(*) FROM songs;

SELECT * FROM tracklists;

SELECT COUNT(*) FROM tracklists;

SELECT * FROM vocals;

SELECT COUNT(*) FROM vocals;
