-- Christopher Creber
-- ccreber@calpoly.edu

-- STUDENT CLEANUP

DROP TABLE teachers;
DROP TABLE students;
