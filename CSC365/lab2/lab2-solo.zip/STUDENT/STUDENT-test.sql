-- Christopher Creber
-- ccreber@calpoly.edu

SELECT * FROM list;

SELECT COUNT(*) FROM list;

SELECT * FROM teachers;

SELECT COUNT(*) FROM teachers;
