-- Christopher Creber
-- ccreber@calpoly.edu

-- BAKERY CLEANUP

DROP TABLE customers;
DROP TABLE goods;
DROP TABLE items;
DROP TABLE receipts;
