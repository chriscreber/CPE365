-- Christopher Creber
-- ccreber@calpoly.edu

-- WINE CLEANUP

DROP TABLE wine;
DROP TABLE grapes;
DROP TABLE appellations;
