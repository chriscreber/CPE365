-- Christopher Creber
-- ccreber@calpoly.edu

-- INN CLEANUP

DROP TABLE reservations;
DROP TABLE rooms;
