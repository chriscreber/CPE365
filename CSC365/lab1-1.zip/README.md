To compile:
javac schoolsearch.java

To Run:
java schoolsearch
