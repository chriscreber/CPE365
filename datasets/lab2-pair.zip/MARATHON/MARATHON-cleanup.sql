-- Christopher Creber, Jett Moy
-- ccreber@calpoly.edu

-- MARATHON CLEANUP

DROP TABLE marathon;
