-- Christopher Creber, Jett Moy
-- ccreber@calpoly.edu

SELECT * FROM marathon;

SELECT COUNT(*) FROM marathon;
