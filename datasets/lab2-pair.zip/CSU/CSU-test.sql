-- Christopher Creber, Jett Moy
-- ccreber@calpoly.edu

SELECT * FROM Campuses;

SELECT COUNT(*) FROM Campuses;

SELECT * FROM csu;

SELECT COUNT(*) FROM csu;

SELECT * FROM degrees;

SELECT COUNT(*) FROM degrees;

SELECT * FROM discipline_enrollments;

SELECT COUNT(*) FROM discipline_enrollments;

SELECT * FROM disciplines;

SELECT COUNT(*) FROM disciplines;

SELECT * FROM enrollments;

SELECT COUNT(*) FROM enrollments;

SELECT * FROM faculty;

SELECT COUNT(*) FROM faculty;
