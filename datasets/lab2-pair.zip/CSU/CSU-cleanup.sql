-- Christopher Creber, Jett Moy
-- ccreber@calpoly.edu

-- CSU CLEANUP

DROP TABLE fees;
DROP TABLE degrees;
DROP TABLE discipline_enrollments;
DROP TABLE disciplines;
DROP TABLE enrollments;
DROP TABLE faculty;
DROP TABLE Campuses;
