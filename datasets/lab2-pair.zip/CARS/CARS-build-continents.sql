-- Christopher Creber, Jett Moy
-- ccreber@calpoly.edu

INSERT INTO continents VALUES (1,'america');
INSERT INTO continents VALUES (2,'europe');
INSERT INTO continents VALUES (3,'asia');
INSERT INTO continents VALUES (4,'africa');
INSERT INTO continents VALUES (5,'australia');
