-- Christopher Creber, Jett Moy
-- ccreber@calpoly.edu

SELECT * FROM car_makers;

SELECT COUNT(*) FROM car_makers;

SELECT * FROM car_names;

SELECT COUNT(*) FROM car_names;

SELECT * FROM cars_data;

SELECT COUNT(*) FROM cars_data;

SELECT * FROM continents;

SELECT COUNT(*) FROM continents;

SELECT * FROM countries;

SELECT COUNT(*) FROM countries;

SELECT * FROM model_list;

SELECT COUNT(*) FROM model_list;
