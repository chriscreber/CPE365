-- Christopher Creber
-- ccreber@calpoly.edu

SELECT * FROM customers;

SELECT COUNT(*) FROM customers;

SELECT * FROM goods;

SELECT COUNT(*) FROM goods;

SELECT * FROM items;

SELECT COUNT(*) FROM items;

SELECT * FROM receipts;

SELECT COUNT(*) FROM receipts;
