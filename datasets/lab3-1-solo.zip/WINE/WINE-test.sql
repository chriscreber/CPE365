-- Christopher Creber
-- ccreber@calpoly.edu

SELECT * FROM appellations;

SELECT COUNT(*) FROM appellations;

SELECT * FROM grapes;

SELECT COUNT(*) FROM grapes;

SELECT * FROM wine;

SELECT COUNT(*) FROM wine;
